USE my_guitar_shop;

DROP TRIGGER IF EXISTS	products_before_update;
DELIMITER //
CREATE TRIGGER 	products_before_update
BEFORE UPDATE ON products
FOR EACH ROW
BEGIN 
if new. list_price > 1200 then 
set message_text = "The Unit Price is too high";
else if new.list_price < 100 then
set message_text = "The Unit price is too low";
end if;
end;
delimiter ; 
update products
set list_price="2000"
